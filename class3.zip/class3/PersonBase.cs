﻿namespace ConsoleAppClass3
{
    internal abstract class PersonBase
    {

        //public int Sum(int a, int b)
        //{
        //    return a + b;
        //}

        //public int Sum(double a, double b)
        //{
        //    return (int)(a + b);
        //}

        public abstract void Bonus();
    }
}