﻿namespace ConsoleAppClass3
{
    internal abstract class PersonBase1
    {
    }
}