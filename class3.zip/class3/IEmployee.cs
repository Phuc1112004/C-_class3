﻿namespace ConsoleAppClass3
{
    internal interface IEmployee
    {
        void Display();
        void Input();
    }
}